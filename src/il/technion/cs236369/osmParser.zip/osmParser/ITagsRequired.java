package il.technion.cs236369.osmParser;
import java.util.Map;

public interface ITagsRequired 
{
	Map<String, String> getTags();
}
