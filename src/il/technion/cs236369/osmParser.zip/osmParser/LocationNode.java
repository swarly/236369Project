package il.technion.cs236369.osmParser;

public class LocationNode {

}
